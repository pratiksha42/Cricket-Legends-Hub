window.addEventListener('scroll', function () {
    let header = document.querySelector('.header');
    header.classList.toggle('scrolled', window.scrollY > 40);
});


document.addEventListener("DOMContentLoaded", function () {
    const map = L.map('map').setView([20.5937, 78.9629], 3);

    // Add a tile layer (background map)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const players = [
        {
            name: "Sir Donald Bradman",
            hometown: "Cootamundra, New South Wales, Australia",
            coordinates: [34.6387, 148.0241]
        },
        {
            name: "Sachin Tendulkar",
            hometown: "Mumbai, India",
            coordinates: [19.076, 72.8777]
        },
        {
            name: "Viv Richards",
            hometown: "St. John's, Antigua",
            coordinates: [17.1274, -61.8468]
        },
        {
            name: "Brian Lara",
            hometown: "Santa Cruz, Trinidad and Tobago",
            coordinates: [10.6412, -61.5121]
        },
        {
            name: "Virat Kohli",
            hometown: "Delhi, India",
            coordinates: [28.6139, 77.2090]
        },
        {
            name: "Imran Khan",
            hometown: "Lahore, West Punjab, Pakistan",
            coordinates: [31.5204, 74.3587]
        },
        {
            name: "Ricky Ponting",
            hometown: "Launceston, Tasmania, Australia",
            coordinates: [41.4391, 147.1358]
        },
        {
            name: "Kapil Dev",
            hometown: "Chandigarh, Punjab, India",
            coordinates: [30.7333, 76.7794]
        }
    ];

    // Loop through players and add markers to the map
    players.forEach(player => {
        L.marker(player.coordinates)
            .addTo(map)
            .bindPopup(`<b>${player.name}</b><br>${player.hometown}`)
            .openPopup();
    });
});

